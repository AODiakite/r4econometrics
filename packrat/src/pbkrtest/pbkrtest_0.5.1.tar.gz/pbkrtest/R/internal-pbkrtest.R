
#' @title Internal functions for the pbkrtest package
#'
#' @description These functions are not intended to be called directly.
#' @name internal
#'
#' @aliases %>% print.PBmodcomp print.summaryPB summary.PBmodcomp
#'     plot.PBmodcomp summary.KRmodcomp print.KRmodcomp 
#'     KRmodcomp_init KRmodcomp_init.lmerMod
#'     KRmodcomp_init.mer as.data.frame.XXmodcomp
#'     tidy
#' 
NULL




