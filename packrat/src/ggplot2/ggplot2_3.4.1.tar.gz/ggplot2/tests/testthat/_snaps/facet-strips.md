# facet_grid() warns about bad switch input

    `switch` must be either "both", "x", or "y"

