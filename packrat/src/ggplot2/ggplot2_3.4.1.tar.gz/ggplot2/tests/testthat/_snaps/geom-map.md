# geom_map() checks its input

    `map` must be a <data.frame>

---

    `map` must have the columns `x`, `y`, and `id`

