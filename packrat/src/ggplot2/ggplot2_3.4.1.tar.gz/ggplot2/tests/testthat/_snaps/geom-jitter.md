# geom_jitter() throws relevant errors

    both `position` and `width`/`height` are supplied
    i Only use one approach to alter the position

