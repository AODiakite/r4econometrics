# unknown device triggers error

    `device` must be "NULL", a string or a function.

# invalid single-string DPI values throw an error

    Unknown `dpi` string
    i Use either "screen", "print", or "retina"

# invalid non-single-string DPI values throw an error

    `dpi` must be a single number or string

---

    `dpi` must be a single number or string

---

    `dpi` must be a single number or string

---

    `dpi` must be a single number or string

