# fortify.default proves a helpful error with class uneval

    `data` must be a <data.frame>, or an object coercible by `fortify()`, not an S3 object with class <uneval>.
    i Did you accidentally pass `aes()` to the `data` argument?

