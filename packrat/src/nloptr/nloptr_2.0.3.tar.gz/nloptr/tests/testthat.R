library(testthat)
library(nloptr)

test_check("nloptr")
