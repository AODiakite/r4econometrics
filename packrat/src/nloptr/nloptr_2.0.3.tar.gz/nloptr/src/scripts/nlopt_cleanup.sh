#!/bin/sh

cp nlopt/include/* ../inst/include/
rm -fr nlopt-src nlopt-build
