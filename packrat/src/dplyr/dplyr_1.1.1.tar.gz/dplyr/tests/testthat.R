library(testthat)
library(dplyr)

test_check("dplyr")
