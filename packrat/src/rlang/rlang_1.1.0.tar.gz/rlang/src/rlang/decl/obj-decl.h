static
r_obj* new_precious_stack(r_obj* x);

static
int push_precious(r_obj* stack);

static
int pop_precious(r_obj* stack);

static
r_obj* as_label_call;
