
renv_envir_self <- function() {
  parent.env(environment())
}
