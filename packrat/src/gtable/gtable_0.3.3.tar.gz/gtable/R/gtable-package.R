#' @keywords internal
#' @aliases NULL
"_PACKAGE"

## usethis namespace: start
#' @import grid
#' @import rlang
#' @importFrom glue glue
#' @importFrom lifecycle deprecated
## usethis namespace: end
NULL
